# Studio UX — паттерны и лейауты

Источники: [Shape of AI](https://www.shapeof.ai), Lovable, Bolt, v0.

## Паттерны Shape of AI в Studio

| Паттерн | Реализация |
|---------|------------|
| **Shared vision** | Split: чат слева + live preview справа на canvas |
| **Initial CTA** | Крупный composer-card внизу чата |
| **Example gallery** | Карточки-примеры в welcome (не мелкие chips) |
| **Suggestions** | Follow-up chips после ответа |
| **Disclosure** | Badge «demo» + «AI disclosure» в preview toolbar |
| **Prompt details** | Status pill «Ожидание БТ» / «Прототип обновлён» |
| **Footprints** | Markdown-ответ ассистента с паттерном и экраном |

## Лейаут

```
┌─────────────────────────┬──┬──────────────────────────────────┐
│ Chat (resizable 360–640)│║│ Preview canvas (dot grid)        │
│ warm parchment #fcfbf8  │║│ browser chrome + iframe          │
│                         │║│                                  │
│ welcome / messages      │║│                                  │
│ composer (elevated card)│║│                                  │
└─────────────────────────┴──┴──────────────────────────────────┘
```

## Токены

- Canvas: `#f0efec` + dot grid
- Surface: `#fcfbf8`
- Card: `#f7f4ed`
- Border: `#eceae4`
- Text: `#1c1c1c` / muted `#5f5f5d`
- Font: DM Sans, letter-spacing −0.015em

## Готовые референсы

- [Shape of AI — Wayfinders & Shared vision](https://www.shapeof.ai)
- [Lovable design system (Refero)](https://styles.refero.design/style/9ff62d34-e48d-4fcb-9fd9-c018e2747542)
- Bolt open-source: `BaseChat.tsx`, `ChatBox.tsx`
- v0: bottom composer, shadcn tokens
