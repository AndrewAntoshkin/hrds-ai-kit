# Cursor → Studio assembly

Тестовый контур: **Cursor собирает**, Studio **показывает** preview. Позже preview на HRDS components.

## Роли

| Слой | Сейчас | Потом |
|------|--------|-------|
| Мозг | Cursor + `hrds-ai-kit` skills/knowledge | тот же + HRDS Storybook/code |
| Spec | JSON `PrototypeSpec` | тот же формат |
| Preview | HTML iframe (prototype-engine) | `@yandex-int/hr-components` |

## Workflow

1. В Cursor опишите БТ со skill `/prototype-builder` или в чате с контекстом kit.
2. Попросите агента вернуть **только JSON** по схеме из `studio/src/lib/prototype-spec.ts`.
3. В Studio → **Spec из Cursor** → вставьте JSON → **Применить**.
4. Справа — preview + панель «Сборка».
5. Чат в Studio — быстрый smoke (rules), не основной путь.

## Что не рендерится в preview

bulk actions, side panel, modals — только в `gaps` / `unsupportedNotes` в spec.
