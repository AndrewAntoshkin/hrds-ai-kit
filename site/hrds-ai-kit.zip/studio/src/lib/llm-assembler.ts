import { buildKitSystemPrompt } from "@/lib/kit-context";
import { getApiKey, getLlmBaseUrl, getModel, hasApiKey } from "@/lib/api-settings";
import {
  specToEngineState,
  SPEC_JSON_SCHEMA,
  type PrototypeSpec,
} from "@/lib/prototype-spec";
import type { PrototypeEngineState } from "@/lib/prototype-engine.js";

export class LlmAssemblyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LlmAssemblyError";
  }
}

function summarizeState(state: PrototypeEngineState): string {
  return JSON.stringify(
    {
      pattern: state.pattern,
      view: state.view,
      title: state.title,
      columns: state.columns,
      actions: state.actions?.map((a) => a.label),
      searchEnabled: state.searchEnabled,
      fields: state.fields?.map((f) => (f as { label?: string }).label),
    },
    null,
    2,
  );
}

export async function assembleWithLlm(
  userText: string,
  options: { currentState?: PrototypeEngineState; isRefinement: boolean },
): Promise<{ state: PrototypeEngineState; reply: string }> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new LlmAssemblyError("Нет API-ключа. Нажмите «API» в шапке Studio.");
  }

  const userPayload = options.isRefinement
    ? `Доработай текущий прототип.\n\nТекущее состояние:\n${summarizeState(options.currentState!)}\n\nЗапрос:\n${userText}`
    : `Собери новый прототип из БТ:\n\n${userText}`;

  const response = await fetch(`${getLlmBaseUrl()}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: getModel(),
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: `${buildKitSystemPrompt()}\n\nJSON schema:\n${SPEC_JSON_SCHEMA}`,
        },
        { role: "user", content: userPayload },
      ],
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new LlmAssemblyError(`LLM ${response.status}: ${body.slice(0, 200)}`);
  }

  const data = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new LlmAssemblyError("Пустой ответ LLM");

  let spec: PrototypeSpec;
  try {
    spec = JSON.parse(content) as PrototypeSpec;
  } catch {
    throw new LlmAssemblyError("LLM вернул невалидный JSON");
  }

  const version = (options.currentState?.version ?? 0) + 1;
  const state = specToEngineState(spec, version);
  return { state, reply: spec.assistantReply || "Сборка готова." };
}

export function canUseLlmAssembly(): boolean {
  return hasApiKey();
}
