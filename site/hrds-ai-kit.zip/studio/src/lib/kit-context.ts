import componentsIndex from "../../../knowledge/components-index.md?raw";
import patternsIndex from "../../../knowledge/patterns-index.md?raw";
import sourcesMd from "../../../knowledge/sources.md?raw";
import architectureMd from "../../../knowledge/architecture.md?raw";

export const KIT_CONTEXT = {
  componentsIndex,
  patternsIndex,
  sources: sourcesMd,
  architecture: architectureMd,
};

export function buildKitSystemPrompt(): string {
  return `Ты — сборщик прототипов HRDS Prototype Studio.
Собирай экраны только из компонентов и паттернов HRDS AI Kit.
Не выдумывай props и API — если нет в индексах, помечай Starter или gap.

## Архитектура
${architectureMd}

## Источники
${sourcesMd}

## Компоненты (index)
${componentsIndex}

## Паттерны (index)
${patternsIndex}

## Preview runtime (что реально рендерится)
- list: таблица с кастомными колонками, поиск, фильтр, кнопки в header, клик по строке → detail
- form: поля text/textarea/select, submit/cancel, submit → success
- dashboard: 4 метрики, вкладки, таблица внизу
- detail: карточка полей из колонок строки

НЕ рендерится (только упомяни в gaps/unsupportedNotes): side panel, bulk actions, wizard steps, nested modals.

Ответ — ТОЛЬКО валидный JSON без markdown-обёртки.`;
}
