import { create } from "zustand";
import {
  buildAssemblyPlan,
  buildKitAssistantReply,
  type AssemblyPlan,
} from "@/lib/assembly-plan";
import {
  applyRefinement,
  createInitialState,
  parseRequirements,
  renderPrototypeDocument,
  type PrototypeEngineState,
} from "@/lib/prototype-engine.js";
import { specToEngineState, type PrototypeSpec } from "@/lib/prototype-spec";

type Store = {
  state: PrototypeEngineState;
  previewHtml: string;
  assemblyPlan: AssemblyPlan | null;
  assemblyMode: "cursor" | "rules";
  hasPrototype: boolean;
  status: string;
  processUserMessage: (text: string) => Promise<{ reply: string; note?: string }>;
  applyCursorSpec: (raw: string) => { reply: string; error?: string };
  applyNavigation: (action: string, rowId?: string) => void;
  reset: () => void;
};

function withAssembly(state: PrototypeEngineState) {
  const plan = buildAssemblyPlan(state);
  return {
    state,
    previewHtml: renderPrototypeDocument(state),
    assemblyPlan: plan,
    assemblyMode: plan.mode,
  };
}

function parseSpec(raw: string): PrototypeSpec {
  const trimmed = raw.trim();
  const jsonText = trimmed.startsWith("```")
    ? trimmed.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "")
    : trimmed;
  return JSON.parse(jsonText) as PrototypeSpec;
}

export const usePrototypeStore = create<Store>((set, get) => ({
  state: createInitialState(),
  previewHtml: "",
  assemblyPlan: null,
  assemblyMode: "rules",
  hasPrototype: false,
  status: "Cursor + kit · вставьте spec",

  applyCursorSpec: (raw) => {
    try {
      const spec = parseSpec(raw);
      const { state } = get();
      const nextState = specToEngineState(spec, state.version + 1);
      nextState.kitMeta = {
        ...nextState.kitMeta!,
        llmReply: spec.assistantReply,
        source: "cursor",
      };

      set({
        ...withAssembly(nextState),
        hasPrototype: true,
        status: "Cursor-сборка применена",
      });

      return {
        reply:
          spec.assistantReply ||
          `Применил spec из Cursor: **${spec.title}** (${spec.hrdsPattern}).`,
      };
    } catch (error) {
      return {
        reply: "",
        error:
          error instanceof Error
            ? error.message
            : "Невалидный JSON spec. См. studio/references/cursor-assembly.md",
      };
    }
  },

  processUserMessage: async (text) => {
    const trimmed = text.trim();
    if (trimmed.startsWith("{") || trimmed.startsWith("```")) {
      const cursorResult = get().applyCursorSpec(trimmed);
      if (!cursorResult.error) {
        return { reply: cursorResult.reply };
      }
    }

    const { hasPrototype, state } = get();
    let note: string | undefined;
    let nextState: PrototypeEngineState;

    if (!hasPrototype) {
      const parsed = parseRequirements(text);
      nextState = { ...state, ...parsed, version: state.version + 1 };
    } else {
      const result = applyRefinement(state, text);
      nextState = result.state;
      note = result.note;
    }

    const reply = buildKitAssistantReply(nextState, hasPrototype, note);

    set({
      ...withAssembly(nextState),
      hasPrototype: true,
      status: "Rules smoke (основной путь — Cursor spec)",
    });

    return { reply, note };
  },

  applyNavigation: (action, rowId) => {
    const { state } = get();
    let nextState: PrototypeEngineState = { ...state, version: state.version + 1 };

    if (action === "detail" && rowId) {
      const row = state.rows.find((r) => r.id === rowId);
      if (!row) return;
      const nameCol =
        state.columns.find((c) => /назван|сотрудник|имя/i.test(c)) ?? state.columns[0];
      nextState = {
        ...nextState,
        view: "detail",
        pattern: "detail",
        detailItem: row,
        breadcrumbs: [
          { label: "Главная", view: "list" },
          { label: state.title, view: "list" },
          {
            label: String(row.cells[nameCol] ?? row.cells[state.columns[0]]),
            view: null,
          },
        ],
      };
    } else if (action === "form") {
      nextState = {
        ...nextState,
        view: "form",
        pattern: "form",
        breadcrumbs: [
          { label: "Главная", view: "list" },
          { label: state.title, view: "list" },
          { label: "Создание", view: null },
        ],
        fields: state.fields.length
          ? state.fields
          : [
              { id: "name", label: "Название", type: "text" },
              { id: "desc", label: "Описание", type: "textarea", optional: true },
            ],
        actions: [
          { id: "submit", label: "Отправить", variant: "default" },
          { id: "cancel", label: "Отмена", variant: "secondary" },
        ],
      };
    } else if (action === "success") {
      nextState = { ...nextState, view: "success" };
    } else if (action === "list") {
      nextState = {
        ...nextState,
        view: state.pattern === "dashboard" ? "dashboard" : "list",
        detailItem: null,
        breadcrumbs: [{ label: "Главная", view: "list" }, { label: state.title, view: null }],
      };
    } else {
      return;
    }

    set({
      ...withAssembly(nextState),
      status: get().assemblyMode === "cursor" ? "Cursor-сборка обновлена" : "Preview обновлён",
    });
  },

  reset: () =>
    set({
      state: createInitialState(),
      previewHtml: "",
      assemblyPlan: null,
      assemblyMode: "rules",
      hasPrototype: false,
      status: "Cursor + kit · вставьте spec",
    }),
}));

export type { PrototypeEngineState, AssemblyPlan };
