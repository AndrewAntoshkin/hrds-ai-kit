/** HRDS AI Kit catalog — mirrors knowledge/components-index + patterns-index */

export type KitStatus = "confirmed" | "starter" | "unknown";

export type KitComponent = {
  name: string;
  status: KitStatus;
  role?: string;
};

export type KitPattern = {
  id: string;
  name: string;
  status: KitStatus;
  components: KitComponent[];
  figma?: string;
};

export type KitSource = {
  href: string;
  title: string;
  description: string;
  domain: string;
};

export const KIT_SOURCES: KitSource[] = [
  {
    href: "https://www.figma.com/design/BodHDPKvwUYhWM5XDahMja",
    title: "HRDS · Компоненты",
    description: "Figma-библиотека компонентов дизайн-системы",
    domain: "figma.com",
  },
  {
    href: "https://hrds.yandex-team.ru",
    title: "HRDS Storybook",
    description: "API компонентов, примеры и controls",
    domain: "hrds.yandex-team.ru",
  },
  {
    href: "https://www.figma.com/files/920787649869095992/project/542725198",
    title: "HRDS · Patterns",
    description: "UX-паттерны и композиции страниц",
    domain: "figma.com",
  },
];

const confirmed = (name: string, role?: string): KitComponent => ({
  name,
  status: "confirmed",
  role,
});

const starter = (name: string, role?: string): KitComponent => ({
  name,
  status: "starter",
  role,
});

export const KIT_PATTERNS: Record<string, KitPattern> = {
  list: {
    id: "data-table",
    name: "Data Table",
    status: "starter",
    components: [
      confirmed("Content Header", "title, description, page actions"),
      confirmed("Button", "primary action «Добавить»"),
      starter("Breadcrumbs", "навигационный путь"),
      starter("Table", "строки данных, sort/filter"),
      starter("Filter", "фильтр по статусу"),
    ],
  },
  form: {
    id: "form-flow",
    name: "Form Flow",
    status: "starter",
    components: [
      confirmed("Content Header", "заголовок формы"),
      confirmed("Button", "submit / cancel"),
      starter("Input", "текстовые поля"),
      starter("Select", "выбор из списка"),
      starter("Inline Message", "валидация"),
    ],
  },
  dashboard: {
    id: "page-header",
    name: "Page Header + Dashboard",
    status: "starter",
    components: [
      confirmed("Content Header", "заголовок дашборда"),
      confirmed("Card", "блоки метрик"),
      confirmed("Button", "экспорт / добавить"),
      starter("Table", "таблица внизу"),
    ],
  },
  detail: {
    id: "detail",
    name: "Detail View",
    status: "starter",
    components: [
      confirmed("Content Header", "имя сущности"),
      confirmed("Button", "редактировать / назад"),
      confirmed("Card", "поля карточки"),
      confirmed("List Item", "атрибуты записи"),
    ],
  },
};

export function getKitPattern(pattern: string | null): KitPattern {
  if (!pattern) {
    return {
      id: "empty",
      name: "—",
      status: "unknown",
      components: [],
    };
  }
  return KIT_PATTERNS[pattern] ?? KIT_PATTERNS.list;
}
