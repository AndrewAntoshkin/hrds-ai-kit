export type PrototypeSpec = {
  pattern: "list" | "form" | "dashboard" | "detail";
  view: "list" | "form" | "dashboard" | "detail" | "success";
  title: string;
  subtitle?: string;
  entityPlural: string;
  entitySingular: string;
  columns: string[];
  rows: Array<{
    id: string;
    cells: Record<string, string>;
  }>;
  fields?: Array<{
    id: string;
    label: string;
    type: "text" | "textarea" | "select";
    optional?: boolean;
    placeholder?: string;
    options?: string[];
  }>;
  actions?: Array<{
    id: string;
    label: string;
    variant?: "default" | "outline" | "secondary";
  }>;
  searchEnabled?: boolean;
  filters?: string[];
  stats?: Array<{ label: string; value: string; delta: string }>;
  hrdsPattern: string;
  hrdsPatternStatus: "confirmed" | "starter" | "unknown";
  hrdsComponents: Array<{
    name: string;
    status: "confirmed" | "starter";
    role?: string;
  }>;
  gaps: string[];
  assistantReply: string;
  unsupportedNotes?: string[];
};

const STATUS_TONES = ["success", "warning", "default", "destructive"] as const;

function normalizeStatus(value: string, index: number) {
  const lower = value.toLowerCase();
  if (/отклон|reject|архив|отказ/i.test(lower)) {
    return { label: value, tone: "destructive" };
  }
  if (/черновик|draft/i.test(lower)) return { label: value, tone: "default" };
  if (/на согласован|ожид|review|pending/i.test(lower)) {
    return { label: value, tone: "warning" };
  }
  if (/согласован|approved|актив/i.test(lower)) {
    return { label: value, tone: "success" };
  }
  return { label: value, tone: STATUS_TONES[index % STATUS_TONES.length] };
}

function normalizeCell(column: string, value: string, index: number) {
  if (/статус|status/i.test(column)) return normalizeStatus(value, index);
  return value;
}

export function specToEngineState(
  spec: PrototypeSpec,
  version: number,
): import("@/lib/prototype-engine.js").PrototypeEngineState {
  const rows = spec.rows.map((row, rowIndex) => ({
    id: row.id || String(rowIndex + 1),
    cells: Object.fromEntries(
      spec.columns.map((col) => [
        col,
        normalizeCell(col, row.cells[col] ?? "—", rowIndex),
      ]),
    ),
  }));

  return {
    pattern: spec.pattern,
    view: spec.view,
    title: spec.title,
    subtitle: spec.subtitle ?? "",
    entity: {
      entity: spec.entityPlural,
      singular: spec.entitySingular,
      sample: spec.rows.map(
        (r) => r.cells[spec.columns[0]] ?? r.cells["Название"] ?? `Запись ${r.id}`,
      ),
    },
    columns: spec.columns,
    rows,
    fields: spec.fields ?? [],
    actions: spec.actions ?? [{ id: "create", label: "Добавить", variant: "default" }],
    filters: spec.filters ?? (spec.searchEnabled ? ["status"] : []),
    stats: spec.stats ?? [],
    detailItem: null,
    breadcrumbs: [
      { label: "Главная", view: "list" },
      { label: spec.title, view: null },
    ],
    activeTab: 0,
    searchEnabled: Boolean(spec.searchEnabled),
    version,
    kitMeta: {
      patternName: spec.hrdsPattern,
      patternStatus: spec.hrdsPatternStatus,
      components: spec.hrdsComponents,
      gaps: [...spec.gaps, ...(spec.unsupportedNotes ?? [])],
      llmReply: spec.assistantReply,
    },
  };
}

export const SPEC_JSON_SCHEMA = `{
  "pattern": "list|form|dashboard|detail",
  "view": "list|form|dashboard|detail",
  "title": "string",
  "subtitle": "string",
  "entityPlural": "string",
  "entitySingular": "string",
  "columns": ["string"],
  "rows": [{ "id": "string", "cells": { "ColumnName": "value" } }],
  "fields": [{ "id": "string", "label": "string", "type": "text|textarea|select", "optional": false, "options": [] }],
  "actions": [{ "id": "string", "label": "string", "variant": "default|outline|secondary" }],
  "searchEnabled": true,
  "filters": ["status"],
  "stats": [{ "label": "string", "value": "string", "delta": "string" }],
  "hrdsPattern": "string from patterns-index",
  "hrdsPatternStatus": "confirmed|starter|unknown",
  "hrdsComponents": [{ "name": "string", "status": "confirmed|starter", "role": "string" }],
  "gaps": ["string"],
  "assistantReply": "markdown for user in Russian",
  "unsupportedNotes": ["features not in preview runtime"]
}`;
