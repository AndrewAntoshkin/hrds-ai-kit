export type PrototypeEngineState = {
  pattern: string | null;
  view: string;
  title: string;
  subtitle: string;
  entity: {
    entity: string;
    singular: string;
    sample: string[];
  };
  columns: string[];
  rows: Array<{ id: string; cells: Record<string, unknown> }>;
  fields: Array<Record<string, unknown>>;
  actions: Array<{ id: string; label: string; variant?: string }>;
  filters: string[];
  stats: Array<Record<string, string>>;
  detailItem: { id: string; cells: Record<string, unknown> } | null;
  breadcrumbs: Array<{ label: string; view: string | null }>;
  activeTab: number;
  searchEnabled: boolean;
  version: number;
  kitMeta?: {
    patternName: string;
    patternStatus: "confirmed" | "starter" | "unknown";
    components: Array<{ name: string; status: "confirmed" | "starter"; role?: string }>;
    gaps: string[];
    llmReply?: string;
    source?: "cursor";
  };
};

export function createInitialState(): PrototypeEngineState;
export function parseRequirements(text: string): Partial<PrototypeEngineState>;
export function applyRefinement(
  state: PrototypeEngineState,
  text: string,
): { state: PrototypeEngineState; note: string };
export function buildAssistantReply(
  state: PrototypeEngineState,
  userText: string,
  isRefinement: boolean,
): string;
export function renderPrototypeDocument(state: PrototypeEngineState): string;
