const STORAGE_KEY = "studio-llm-api-key";
const MODEL_KEY = "studio-llm-model";

export function getApiKey(): string | null {
  const fromEnv = import.meta.env.VITE_OPENAI_API_KEY;
  if (typeof fromEnv === "string" && fromEnv.trim()) return fromEnv.trim();
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored?.trim() || null;
}

export function setApiKey(key: string) {
  localStorage.setItem(STORAGE_KEY, key.trim());
}

export function clearApiKey() {
  localStorage.removeItem(STORAGE_KEY);
}

export function hasApiKey(): boolean {
  return Boolean(getApiKey());
}

export function getModel(): string {
  return localStorage.getItem(MODEL_KEY) || import.meta.env.VITE_LLM_MODEL || "gpt-4o-mini";
}

export function setModel(model: string) {
  localStorage.setItem(MODEL_KEY, model.trim());
}

export function getLlmBaseUrl(): string {
  return import.meta.env.VITE_LLM_BASE_URL || "https://api.openai.com/v1";
}
