import {
  getKitPattern,
  KIT_SOURCES,
  type KitComponent,
  type KitPattern,
  type KitSource,
} from "@/lib/kit-catalog";
import type { PrototypeEngineState } from "@/lib/prototype-engine.js";

export type AssemblyPlan = {
  pattern: KitPattern;
  components: KitComponent[];
  sources: KitSource[];
  gaps: string[];
  screenTitle: string;
  mode: "cursor" | "rules";
};

export function buildAssemblyPlan(state: PrototypeEngineState): AssemblyPlan {
  if (state.kitMeta) {
    return {
      pattern: {
        id: state.pattern ?? "custom",
        name: state.kitMeta.patternName,
        status: state.kitMeta.patternStatus,
        components: state.kitMeta.components,
      },
      components: state.kitMeta.components,
      sources: KIT_SOURCES,
      gaps: state.kitMeta.gaps,
      screenTitle: state.title || "Экран",
      mode: state.kitMeta.source === "cursor" ? "cursor" : "rules",
    };
  }

  const pattern = getKitPattern(state.pattern);
  const components = [...pattern.components];
  const gaps: string[] = [];

  if (pattern.status === "starter") {
    gaps.push(`Паттерн «${pattern.name}» — Starter, нужен node URL в Figma Patterns`);
  }

  for (const c of components) {
    if (c.status === "starter") {
      gaps.push(`Компонент «${c.name}» — Starter, проверить в Storybook`);
    }
  }

  if (state.searchEnabled && !components.some((c) => c.name === "Filter")) {
    components.push({ name: "Filter", status: "starter", role: "поиск и фильтры" });
  }

  if (state.fields?.length && !components.some((c) => c.name === "Input")) {
    components.push({ name: "Input", status: "starter", role: "поля формы" });
  }

  return {
    pattern,
    components,
    sources: KIT_SOURCES,
    gaps,
    screenTitle: state.title || "Экран",
    mode: "rules",
  };
}

export function buildKitAssistantReply(
  state: PrototypeEngineState,
  isRefinement: boolean,
  note?: string,
): string {
  if (state.kitMeta?.llmReply && !isRefinement) {
    return state.kitMeta.llmReply;
  }

  const plan = buildAssemblyPlan(state);
  const lines: string[] = [];

  if (!isRefinement) {
    lines.push("Собрал прототип по **HRDS AI Kit** (rule-based fallback).");
    lines.push("");
    lines.push(`**Паттерн:** ${plan.pattern.name} (${plan.pattern.status})`);
    lines.push(`**Экран:** ${plan.screenTitle}`);
    lines.push("");
    lines.push("**Композиция:**");
    for (const c of plan.components) {
      const tag = c.status === "confirmed" ? "✓" : "~";
      lines.push(`- ${tag} **${c.name}**${c.role ? ` — ${c.role}` : ""}`);
    }
    if (state.searchEnabled) lines.push("- Поиск и фильтры включены");
    if (state.actions?.length) {
      lines.push(`- Действия: ${state.actions.map((a) => a.label).join(", ")}`);
    }
    lines.push("");
    lines.push("_Основной путь: соберите spec в Cursor и вставьте через «Spec из Cursor»._");
  } else {
    lines.push("Обновил сборку (rules).");
    if (note) lines.push(`_${note}_`);
  }

  if (plan.gaps.length && !isRefinement) {
    lines.push("");
    lines.push("**Нужна проверка:**");
    for (const gap of plan.gaps.slice(0, 3)) {
      lines.push(`- ${gap}`);
    }
  }

  return lines.join("\n");
}
