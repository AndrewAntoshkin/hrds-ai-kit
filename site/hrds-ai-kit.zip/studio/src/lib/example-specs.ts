import type { PrototypeSpec } from "@/lib/prototype-spec";

/** Готовый spec для smoke-теста реальной сборки (Cursor → Studio → preview) */
export const BUSINESS_TRIPS_SPEC: PrototypeSpec = {
  pattern: "list",
  view: "list",
  title: "Согласование командировок",
  subtitle: "Заявки в зоне ответственности HR BP",
  entityPlural: "командировки",
  entitySingular: "командировка",
  columns: [
    "Сотрудник",
    "Направление",
    "Даты",
    "Бюджет",
    "Согласующий",
    "Статус согласования",
  ],
  rows: [
    {
      id: "1",
      cells: {
        Сотрудник: "Иванов А.П.",
        Направление: "Стамбул",
        Даты: "12.07 — 18.07.2026",
        Бюджет: "84 000 ₽",
        Согласующий: "Петрова М.",
        "Статус согласования": "На согласовании",
      },
    },
    {
      id: "2",
      cells: {
        Сотрудник: "Козлова Е.Д.",
        Направление: "Берлин",
        Даты: "22.07 — 26.07.2026",
        Бюджет: "112 500 ₽",
        Согласующий: "Сидоров К.",
        "Статус согласования": "Согласовано",
      },
    },
    {
      id: "3",
      cells: {
        Сотрудник: "Петров Д.В.",
        Направление: "Тбилиси",
        Даты: "01.08 — 05.08.2026",
        Бюджет: "46 200 ₽",
        Согласующий: "Петрова М.",
        "Статус согласования": "Черновик",
      },
    },
    {
      id: "4",
      cells: {
        Сотрудник: "Смирнова О.Л.",
        Направление: "Алматы",
        Даты: "15.08 — 20.08.2026",
        Бюджет: "67 800 ₽",
        Согласующий: "Сидоров К.",
        "Статус согласования": "Отклонено",
      },
    },
    {
      id: "5",
      cells: {
        Сотрудник: "Волков И.С.",
        Направление: "Дубай",
        Даты: "03.09 — 10.09.2026",
        Бюджет: "198 000 ₽",
        Согласующий: "Петрова М.",
        "Статус согласования": "На согласовании",
      },
    },
  ],
  actions: [
    { id: "create", label: "Создать заявку", variant: "default" },
    { id: "export", label: "Экспорт в 1С", variant: "outline" },
  ],
  searchEnabled: true,
  filters: ["status"],
  hrdsPattern: "Data Table",
  hrdsPatternStatus: "starter",
  hrdsComponents: [
    { name: "Content Header", status: "confirmed", role: "заголовок и действия страницы" },
    { name: "Button", status: "confirmed", role: "Создать заявку, Экспорт" },
    { name: "Breadcrumbs", status: "starter", role: "навигация" },
    { name: "Table", status: "starter", role: "заявки на командировки" },
    { name: "Filter", status: "starter", role: "поиск и фильтр по статусу" },
  ],
  gaps: [
    "Bulk «Согласовать выбранные» — не рендерится в HTML preview",
    "Сайдпанель истории согласования — только в gaps",
    "Паттерн Data Table — Starter, нужен node URL в Figma Patterns",
  ],
  unsupportedNotes: ["side panel", "bulk selection"],
  assistantReply: `Собрал **Согласование командировок** по HRDS AI Kit.

**Паттерн:** Data Table (starter)
**Колонки:** Сотрудник, Направление, Даты, Бюджет, Согласующий, Статус

**Композиция:**
- ✓ Content Header — заголовок и кнопки
- ✓ Button — «Создать заявку», «Экспорт в 1С»
- ~ Table, Filter, Breadcrumbs

Preview на HTML-прототипе (позже → HRDS components).`,
};

export function specToJson(spec: PrototypeSpec): string {
  return JSON.stringify(spec, null, 2);
}
