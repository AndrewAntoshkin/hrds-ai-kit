import { useCallback, useEffect, useRef, useState } from "react";

const MIN = 360;
const MAX = 640;
const DEFAULT = 440;

export function StudioResizer({
  onWidthChange,
}: {
  onWidthChange: (width: number) => void;
}) {
  const [dragging, setDragging] = useState(false);
  const startX = useRef(0);
  const startWidth = useRef(DEFAULT);

  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      e.preventDefault();
      const shell = document.querySelector(".studio-app");
      const current = shell
        ? parseInt(getComputedStyle(shell).gridTemplateColumns.split(" ")[0], 10)
        : DEFAULT;
      startX.current = e.clientX;
      startWidth.current = Number.isFinite(current) ? current : DEFAULT;
      setDragging(true);
      e.currentTarget.setPointerCapture(e.pointerId);
    },
    [],
  );

  useEffect(() => {
    if (!dragging) return;

    const onMove = (e: globalThis.PointerEvent) => {
      const next = Math.min(MAX, Math.max(MIN, startWidth.current + e.clientX - startX.current));
      onWidthChange(next);
    };

    const onUp = () => setDragging(false);

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";

    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [dragging, onWidthChange]);

  return (
    <div
      className={`studio-resizer${dragging ? " is-dragging" : ""}`}
      role="separator"
      aria-orientation="vertical"
      aria-label="Изменить ширину панели чата"
      onPointerDown={onPointerDown}
    />
  );
}
