import type { FC } from "react";

const CAPABILITIES = [
  { label: "Таблицы и фильтры", tone: "indigo" },
  { label: "Формы и шаги", tone: "amber" },
  { label: "Дашборды", tone: "teal" },
  { label: "Доработка в диалоге", tone: "rose" },
  { label: "Компоненты HRDS", tone: "violet" },
  { label: "Preview в реальном времени", tone: "slate" },
] as const;

export const StudioWelcome: FC = () => {
  return (
    <div className="studio-welcome">
      <div className="studio-welcome-hero">
        <div className="studio-welcome-avatar" aria-hidden>
          ✦
        </div>
        <p className="studio-welcome-eyebrow">Shared vision</p>
        <h2 className="studio-welcome-title">Опишите экран — соберём прототип</h2>
        <p className="studio-welcome-sub">
          Сборка — в Cursor по <code>hrds-ai-kit</code>. Вставьте JSON spec через
          «Spec из Cursor» — preview справа.
        </p>
      </div>

      <div className="studio-capabilities">
        <p className="studio-capabilities-label">Что умею</p>
        <div className="studio-capabilities-pills">
          {CAPABILITIES.map((item) => (
            <span
              key={item.label}
              className={`studio-capability-pill studio-capability-pill-${item.tone}`}
            >
              {item.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
