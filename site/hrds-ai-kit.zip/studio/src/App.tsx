import { useState } from "react";
import { PreviewPanel } from "@/PreviewPanel";
import { StudioChat } from "@/StudioChat";
import { StudioResizer } from "@/StudioResizer";
import "./studio-shell.css";

export default function App() {
  const [sidebarWidth, setSidebarWidth] = useState(440);

  return (
    <div
      className="studio-app"
      style={{ gridTemplateColumns: `${sidebarWidth}px 6px 1fr` }}
    >
      <aside className="studio-chat" aria-label="Ассистент">
        <header className="studio-chat-header">
          <div className="studio-brand">
            <div className="studio-brand-mark" aria-hidden>
              <span>◇</span>
            </div>
            <div className="studio-brand-text">
              <p className="studio-brand-title">Prototype Studio</p>
              <p className="studio-brand-sub">Cursor · HRDS AI Kit</p>
            </div>
          </div>
          <span className="studio-badge" title="Сборка через Cursor spec">
            kit
          </span>
        </header>
        <div className="studio-chat-body">
          <StudioChat />
        </div>
      </aside>

      <StudioResizer onWidthChange={setSidebarWidth} />
      <PreviewPanel />
    </div>
  );
}
