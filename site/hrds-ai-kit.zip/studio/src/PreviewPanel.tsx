import { AssemblyBar } from "@/AssemblyBar";
import { CursorSpecPanel } from "@/CursorSpecPanel";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { usePrototypeStore } from "@/lib/prototype-store";

export function PreviewPanel() {
  const previewHtml = usePrototypeStore((s) => s.previewHtml);
  const status = usePrototypeStore((s) => s.status);
  const hasPrototype = usePrototypeStore((s) => s.hasPrototype);
  const reset = usePrototypeStore((s) => s.reset);
  const applyNavigation = usePrototypeStore((s) => s.applyNavigation);

  useEffect(() => {
    const handler = (event: MessageEvent) => {
      if (event.data?.type !== "proto-nav") return;
      applyNavigation(event.data.action, event.data.rowId);
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [applyNavigation]);

  return (
    <section className="studio-preview" aria-label="Preview">
      <header className="studio-preview-toolbar">
        <div className="studio-preview-toolbar-left">
          <a className="studio-preview-link" href="../index.html">
            ← Лендинг
          </a>
          <span className="studio-preview-divider" aria-hidden />
          <span className="studio-preview-title">Preview</span>
          <span
            className={`studio-status-pill${hasPrototype ? " is-live" : ""}`}
          >
            <span className="studio-status-dot" aria-hidden />
            {status}
          </span>
        </div>
        <div className="studio-preview-toolbar-right">
          <CursorSpecPanel />
          <Button variant="outline" size="sm" className="studio-reset-btn" onClick={reset}>
            Сбросить
          </Button>
        </div>
      </header>

      <AssemblyBar />

      <div className="studio-preview-wrap">
        {!hasPrototype ? (
          <div className="studio-preview-empty">
            <p>Соберите spec в Cursor → «Spec из Cursor» → preview справа</p>
            <p className="studio-preview-empty-sub">
              Чат слева — rules smoke. См. <code>studio/references/cursor-assembly.md</code>
            </p>
          </div>
        ) : (
          <iframe
            className="studio-preview-iframe"
            title="Prototype preview"
            srcDoc={previewHtml}
            sandbox="allow-scripts allow-same-origin"
          />
        )}
      </div>
    </section>
  );
}
