import { ArrowUp } from "lucide-react";
import { useCallback, useId, useState } from "react";
import {
  ChatContainerContent,
  ChatContainerRoot,
} from "@/components/prompt-kit/chat-container";
import { Loader } from "@/components/prompt-kit/loader";
import {
  Message,
  MessageAvatar,
  MessageContent,
} from "@/components/prompt-kit/message";
import {
  PromptInput,
  PromptInputAction,
  PromptInputActions,
  PromptInputTextarea,
} from "@/components/prompt-kit/prompt-input";
import { PromptSuggestion } from "@/components/prompt-kit/prompt-suggestion";
import {
  Source,
  SourceContent,
  SourceTrigger,
} from "@/components/prompt-kit/source";
import { Button } from "@/components/ui/button";
import { usePrototypeStore } from "@/lib/prototype-store";
import { StudioWelcome } from "@/StudioWelcome";
import "./studio-chat.css";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

const FOLLOW_UP_SUGGESTIONS = [
  "добавь кнопку «Экспорт в 1С»",
  "добавь колонку «Центр затрат»",
  "добавь поиск и фильтр",
] as const;

export function StudioChat() {
  const formId = useId();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const hasPrototype = usePrototypeStore((s) => s.hasPrototype);
  const assemblyPlan = usePrototypeStore((s) => s.assemblyPlan);
  const processUserMessage = usePrototypeStore((s) => s.processUserMessage);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || isLoading) return;

      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "user", content: trimmed },
      ]);
      setInput("");
      setIsLoading(true);

      try {
        const { reply } = await processUserMessage(trimmed);
        setMessages((prev) => [
          ...prev,
          { id: crypto.randomUUID(), role: "assistant", content: reply },
        ]);
      } catch {
        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content:
              "**Ошибка.** Для реальной сборки используйте Cursor → «Spec из Cursor».",
          },
        ]);
      } finally {
        setIsLoading(false);
      }
    },
    [isLoading, processUserMessage],
  );

  const suggestions = messages.length > 0 ? FOLLOW_UP_SUGGESTIONS : [];

  return (
    <div className="studio-chat-layout">
      <ChatContainerRoot className="studio-chat-scroll">
        <ChatContainerContent className="studio-chat-messages">
          {messages.length === 0 && !isLoading ? (
            <StudioWelcome />
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={
                  message.role === "user"
                    ? "studio-message-user-wrap"
                    : "studio-message-assistant-wrap"
                }
              >
                <Message
                  className={
                    message.role === "user"
                      ? "studio-message studio-message-user"
                      : "studio-message studio-message-assistant"
                  }
                >
                  {message.role === "assistant" && (
                    <MessageAvatar
                      alt="Ассистент"
                      src=""
                      fallback="✦"
                      className="studio-message-avatar"
                    />
                  )}
                  <MessageContent
                    markdown={message.role === "assistant"}
                    className={
                      message.role === "user"
                        ? "studio-message-bubble studio-message-bubble-user"
                        : "studio-message-bubble studio-message-bubble-assistant"
                    }
                  >
                    {message.content}
                  </MessageContent>
                </Message>

                {message.role === "assistant" && hasPrototype && assemblyPlan && (
                  <div className="studio-message-sources">
                    {assemblyPlan.sources.map((source) => (
                      <Source key={source.href} href={source.href}>
                        <SourceTrigger showFavicon label={source.domain} />
                        <SourceContent
                          title={source.title}
                          description={source.description}
                        />
                      </Source>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}

          {isLoading && (
            <Message className="studio-message studio-message-assistant">
              <MessageAvatar
                alt="Ассистент"
                src=""
                fallback="✦"
                className="studio-message-avatar"
              />
              <div className="studio-message-bubble studio-message-bubble-assistant studio-message-loading">
                <Loader variant="text-shimmer" text="Rules smoke…" size="sm" />
              </div>
            </Message>
          )}
        </ChatContainerContent>
      </ChatContainerRoot>

      <footer className="studio-chat-footer">
        {!isLoading && suggestions.length > 0 && (
          <div className="studio-chat-suggestions">
            {suggestions.map((prompt) => (
              <PromptSuggestion
                key={prompt}
                type="button"
                onClick={() => sendMessage(prompt)}
              >
                {prompt}
              </PromptSuggestion>
            ))}
          </div>
        )}

        <PromptInput
          value={input}
          onValueChange={setInput}
          onSubmit={() => sendMessage(input)}
          isLoading={isLoading}
          disabled={isLoading}
          className="studio-prompt-input"
        >
          <PromptInputTextarea
            placeholder="Опишите экран или доработку…"
            aria-label="Сообщение ассистенту"
          />
          <PromptInputActions className="studio-prompt-actions">
            <PromptInputAction tooltip="Отправить · Enter">
              <Button
                type="button"
                size="icon"
                className="studio-send-button"
                disabled={!input.trim() || isLoading}
                onClick={() => sendMessage(input)}
                aria-label="Отправить"
              >
                <ArrowUp className="size-4" />
              </Button>
            </PromptInputAction>
          </PromptInputActions>
        </PromptInput>

        <p className="studio-chat-hint" id={`${formId}-hint`}>
          Enter — отправить · Shift+Enter — новая строка
        </p>
      </footer>
    </div>
  );
}
