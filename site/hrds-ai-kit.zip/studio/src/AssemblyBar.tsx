import { usePrototypeStore } from "@/lib/prototype-store";

export function AssemblyBar() {
  const assemblyPlan = usePrototypeStore((s) => s.assemblyPlan);

  if (!assemblyPlan) return null;

  return (
    <div className="studio-assembly-bar" aria-label="Сборка HRDS">
      <span className="studio-assembly-label">Сборка</span>
      <span className="studio-assembly-pattern" title={`Статус: ${assemblyPlan.pattern.status}`}>
        {assemblyPlan.pattern.name}
      </span>
      {assemblyPlan.components.map((component) => (
        <span
          key={`${component.name}-${component.role ?? ""}`}
          className={`studio-assembly-chip studio-assembly-chip--${component.status}`}
          title={component.role}
        >
          {component.name}
        </span>
      ))}
    </div>
  );
}
