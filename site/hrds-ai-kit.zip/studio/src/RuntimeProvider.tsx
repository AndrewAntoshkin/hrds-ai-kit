import {
  AssistantRuntimeProvider,
  useLocalRuntime,
  type ChatModelAdapter,
  type ThreadMessage,
} from "@assistant-ui/react";
import type { ReactNode } from "react";
import { usePrototypeStore } from "@/lib/prototype-store";

const WELCOME_SUGGESTIONS = [
  "Список сотрудников с поиском и фильтрами",
  "Экран «Заявка на отпуск» — форма с отправкой",
  "Дашборд по заявкам с метриками",
];

function getLastUserText(messages: readonly ThreadMessage[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const message = messages[i];
    if (message.role !== "user") continue;
    return message.content
      .filter((part) => part.type === "text")
      .map((part) => part.text)
      .join("\n")
      .trim();
  }
  return "";
}

const prototypeAdapter: ChatModelAdapter = {
  async *run({ messages, abortSignal }) {
    const userText = getLastUserText(messages);
    if (!userText) {
      yield { content: [{ type: "text", text: "Опишите экран или доработку." }] };
      return;
    }

    yield {
      content: [{ type: "text", text: "Собираю прототип…" }],
    };

    await new Promise((resolve, reject) => {
      const timer = window.setTimeout(resolve, 450);
      abortSignal?.addEventListener("abort", () => {
        window.clearTimeout(timer);
        reject(new DOMException("Aborted", "AbortError"));
      });
    });

    if (abortSignal?.aborted) return;

    const { reply } = await usePrototypeStore.getState().processUserMessage(userText);
    yield { content: [{ type: "text", text: reply }] };
  },
};

export function RuntimeProvider({ children }: { children: ReactNode }) {
  const runtime = useLocalRuntime(prototypeAdapter, {
    adapters: {
      suggestion: {
        async *generate({ messages }) {
          if (messages.length === 0) {
            yield WELCOME_SUGGESTIONS.map((prompt) => ({ prompt }));
            return;
          }
          yield [
            { prompt: "добавь кнопку «Экспорт»" },
            { prompt: "добавь колонку Отдел" },
            { prompt: "сделай форму создания" },
          ];
        },
      },
    },
  });

  return (
    <AssistantRuntimeProvider runtime={runtime}>{children}</AssistantRuntimeProvider>
  );
}
