import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BUSINESS_TRIPS_SPEC, specToJson } from "@/lib/example-specs";
import { usePrototypeStore } from "@/lib/prototype-store";

export function CursorSpecPanel() {
  const [open, setOpen] = useState(false);
  const [raw, setRaw] = useState("");
  const [error, setError] = useState<string | null>(null);
  const applyCursorSpec = usePrototypeStore((s) => s.applyCursorSpec);

  const apply = () => {
    const result = applyCursorSpec(raw);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError(null);
    setOpen(false);
  };

  const loadExample = () => {
    setRaw(specToJson(BUSINESS_TRIPS_SPEC));
    setError(null);
    const result = applyCursorSpec(specToJson(BUSINESS_TRIPS_SPEC));
    if (result.error) setError(result.error);
    else setOpen(false);
  };

  return (
    <div className="studio-cursor-spec">
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="studio-cursor-spec-toggle"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        Spec из Cursor
      </Button>

      {open && (
        <div className="studio-cursor-spec-panel">
          <p className="studio-cursor-spec-hint">
            Сборка через Cursor: агент читает <code>hrds-ai-kit</code>, отдаёт JSON spec —
            вставьте сюда.
          </p>
          <textarea
            className="studio-cursor-spec-input"
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder='{ "pattern": "list", "title": "…", "columns": […], … }'
            spellCheck={false}
          />
          {error ? <p className="studio-cursor-spec-error">{error}</p> : null}
          <div className="studio-cursor-spec-actions">
            <Button type="button" size="sm" variant="secondary" onClick={loadExample}>
              Пример: командировки
            </Button>
            <Button type="button" size="sm" onClick={apply} disabled={!raw.trim()}>
              Применить spec
            </Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setOpen(false)}>
              Закрыть
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
