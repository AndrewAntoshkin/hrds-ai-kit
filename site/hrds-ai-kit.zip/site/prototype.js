import {
  createInitialState,
  parseRequirements,
  applyRefinement,
  buildAssistantReply,
  renderPrototypeDocument,
} from "./prototype-engine.js";

const EXAMPLE_PROMPTS = [
  "Список сотрудников с поиском и фильтрами",
  "Экран «Заявка на отпуск» — форма с отправкой",
  "Дашборд по заявкам с метриками",
  "Список кандидатов, кнопка Добавить",
];

const messagesEl = document.querySelector("[data-messages]");
const formEl = document.querySelector("[data-composer-form]");
const inputEl = document.querySelector("[data-composer-input]");
const sendBtn = document.querySelector("[data-send]");
const iframeEl = document.querySelector("[data-preview-iframe]");
const emptyEl = document.querySelector("[data-preview-empty]");
const statusEl = document.querySelector("[data-status-text]");
const statusDot = document.querySelector("[data-status-dot]");
const resetBtn = document.querySelector("[data-reset]");
const chipsEl = document.querySelector("[data-chips]");

let state = createInitialState();
let hasPrototype = false;
let isBusy = false;

init();

function init() {
  renderChips();
  renderWelcome();

  formEl?.addEventListener("submit", (e) => {
    e.preventDefault();
    submitMessage();
  });

  inputEl?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submitMessage();
    }
  });

  inputEl?.addEventListener("input", autoResize);

  resetBtn?.addEventListener("click", resetStudio);

  window.addEventListener("message", handleProtoMessage);

  chipsEl?.addEventListener("click", (e) => {
    const chip = e.target.closest("[data-chip]");
    if (!chip || !inputEl) return;
    inputEl.value = chip.dataset.chip || "";
    autoResize();
    inputEl.focus();
  });
}

function renderWelcome() {
  if (!messagesEl) return;
  const welcome = document.createElement("div");
  welcome.className = "studio-welcome";
  welcome.innerHTML = `
    <strong>Prototype Studio</strong> — тестовый режим на shadcn-компонентах.
    Опишите бизнес-требования слева, справа соберётся кликабельный прототип.
    Потом можно дорабатывать: «добавь кнопку Экспорт», «добавь колонку Отдел».
    <div class="studio-chips" data-chips-inline></div>
  `;
  messagesEl.appendChild(welcome);

  const inlineChips = welcome.querySelector("[data-chips-inline]");
  EXAMPLE_PROMPTS.forEach((text) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "studio-chip";
    btn.dataset.chip = text;
    btn.textContent = text;
    btn.addEventListener("click", () => {
      if (!inputEl) return;
      inputEl.value = text;
      autoResize();
      submitMessage();
    });
    inlineChips?.appendChild(btn);
  });
}

function renderChips() {
  if (!chipsEl) return;
  chipsEl.innerHTML = "";
  EXAMPLE_PROMPTS.slice(0, 2).forEach((text) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "studio-chip";
    btn.dataset.chip = text;
    btn.textContent = text;
    chipsEl.appendChild(btn);
  });
}

async function submitMessage() {
  if (!inputEl || isBusy) return;
  const text = inputEl.value.trim();
  if (!text) return;

  inputEl.value = "";
  autoResize();
  appendMessage("user", text);

  isBusy = true;
  sendBtn.disabled = true;
  setStatus("Генерация…", true);
  const typing = showTyping();

  await delay(500 + Math.random() * 400);

  const isRefinement = hasPrototype;
  let note = "";

  if (!hasPrototype) {
    const parsed = parseRequirements(text);
    state = { ...state, ...parsed, version: state.version + 1 };
    hasPrototype = true;
  } else {
    const result = applyRefinement(state, text);
    state = result.state;
    note = result.note;
  }

  const reply = buildAssistantReply(state, text, isRefinement);
  const fullReply = note ? `${reply}\n\n_${note}_` : reply;

  typing.remove();
  appendMessage("assistant", fullReply);
  renderPreview();
  setStatus("Прототип обновлён", false);

  isBusy = false;
  sendBtn.disabled = false;
  inputEl.focus();
}

function appendMessage(role, text) {
  if (!messagesEl) return;

  const welcome = messagesEl.querySelector(".studio-welcome");
  if (welcome && role === "user") welcome.remove();

  const msg = document.createElement("div");
  msg.className = `studio-msg studio-msg--${role}`;

  const label = document.createElement("span");
  label.className = "studio-msg-label";
  label.textContent = role === "user" ? "Вы" : "Ассистент";

  const bubble = document.createElement("div");
  bubble.className = "studio-msg-bubble";
  bubble.textContent = text;

  msg.append(label, bubble);
  messagesEl.appendChild(msg);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showTyping() {
  const el = document.createElement("div");
  el.className = "studio-msg studio-msg--assistant";
  el.innerHTML = `
    <span class="studio-msg-label">Ассистент</span>
    <div class="studio-typing" aria-label="Печатает"><span></span><span></span><span></span></div>
  `;
  messagesEl?.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return el;
}

function renderPreview() {
  if (!iframeEl || !emptyEl) return;

  const html = renderPrototypeDocument(state);
  iframeEl.removeAttribute("src");
  iframeEl.srcdoc = html;

  emptyEl.hidden = true;
  iframeEl.hidden = false;
}

function handleProtoMessage(event) {
  if (!event.data || event.data.type !== "proto-nav") return;

  const { action, rowId } = event.data;

  if (action === "detail" && rowId) {
    const row = state.rows.find((r) => r.id === rowId);
    if (!row) return;
    state = {
      ...state,
      view: "detail",
      detailItem: row,
      version: state.version + 1,
      breadcrumbs: [
        { label: "Главная", view: "list" },
        { label: state.title, view: "list" },
        { label: String(row.cells["Название"] || row.cells[state.columns[0]]), view: null },
      ],
    };
    renderPreview();
    return;
  }

  if (action === "form") {
    state = {
      ...state,
      view: "form",
      pattern: "form",
      version: state.version + 1,
      breadcrumbs: [
        { label: "Главная", view: "list" },
        { label: state.title, view: "list" },
        { label: "Создание", view: null },
      ],
      fields: state.fields.length
        ? state.fields
        : [
            { id: "name", label: "Название", type: "text" },
            { id: "desc", label: "Описание", type: "textarea", optional: true },
          ],
      actions: [
        { id: "submit", label: "Отправить", variant: "default" },
        { id: "cancel", label: "Отмена", variant: "secondary" },
      ],
    };
    renderPreview();
    return;
  }

  if (action === "success") {
    state = { ...state, view: "success", version: state.version + 1 };
    renderPreview();
    return;
  }

  if (action === "list") {
    state = {
      ...state,
      view: state.pattern === "dashboard" ? "dashboard" : "list",
      detailItem: null,
      version: state.version + 1,
      breadcrumbs: [{ label: "Главная", view: "list" }, { label: state.title, view: null }],
    };
    renderPreview();
  }
}

function resetStudio() {
  state = createInitialState();
  hasPrototype = false;
  if (messagesEl) {
    messagesEl.innerHTML = "";
    renderWelcome();
  }
  if (iframeEl) {
    iframeEl.hidden = true;
    iframeEl.removeAttribute("src");
    iframeEl.removeAttribute("srcdoc");
  }
  if (emptyEl) emptyEl.hidden = false;
  setStatus("Ожидание БТ", false);
  inputEl?.focus();
}

function setStatus(text, busy) {
  if (statusEl) statusEl.textContent = text;
  statusDot?.classList.toggle("is-idle", !busy && !hasPrototype);
}

function autoResize() {
  if (!inputEl) return;
  inputEl.style.height = "auto";
  inputEl.style.height = `${Math.min(inputEl.scrollHeight, 160)}px`;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
