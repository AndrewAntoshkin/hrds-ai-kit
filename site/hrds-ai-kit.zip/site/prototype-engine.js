/**
 * Rule-based prototype generator (demo).
 * Parses business requirements → shadcn-styled clickable UI.
 */

const ENTITY_PATTERNS = [
  { re: /сотрудник|employee|staff/i, entity: "сотрудники", singular: "сотрудник", sample: ["Иванов А.П.", "Петрова М.С.", "Сидоров К.В.", "Козлова Е.Д."] },
  { re: /заявк|request|ticket/i, entity: "заявки", singular: "заявка", sample: ["Заявка #1042", "Заявка #1041", "Заявка #1039", "Заявка #1035"] },
  { re: /отпуск|vacation|leave/i, entity: "отпуска", singular: "отпуск", sample: ["Ежегодный", "Без сохранения ЗП", "Учебный", "По уходу"] },
  { re: /кандидат|candidate|рекрут/i, entity: "кандидаты", singular: "кандидат", sample: ["Frontend · Senior", "Product · Middle", "HR BP", "Designer"] },
  { re: /документ|document/i, entity: "документы", singular: "документ", sample: ["Договор", "Приказ", "Справка", "Акт"] },
];

const DEFAULT_ENTITY = { entity: "записи", singular: "запись", sample: ["Запись 1", "Запись 2", "Запись 3", "Запись 4"] };

export function createInitialState() {
  return {
    pattern: null,
    view: "empty",
    title: "",
    subtitle: "",
    entity: DEFAULT_ENTITY,
    columns: [],
    rows: [],
    fields: [],
    actions: [],
    filters: [],
    stats: [],
    detailItem: null,
    breadcrumbs: [],
    activeTab: 0,
    searchEnabled: false,
    version: 0,
  };
}

export function parseRequirements(text) {
  const t = text.trim();
  const lower = t.toLowerCase();

  let pattern = "list";
  if (/форм|создан|заявк|отправ|заполн|create|submit|application/i.test(t)) pattern = "form";
  if (/дашборд|dashboard|метрик|аналитик|статистик|kpi/i.test(t)) pattern = "dashboard";
  if (/карточк|детал|profile|профил/i.test(t) && !/список|list|таблиц/i.test(t)) pattern = "detail";

  const entityMatch = ENTITY_PATTERNS.find((p) => p.re.test(t)) || DEFAULT_ENTITY;

  let title = "";
  const titleMatch = t.match(/[«"]([^»"]+)[»"]/);
  if (titleMatch) {
    title = titleMatch[1];
  } else if (/список/i.test(t)) {
    title = `Список ${entityMatch.entity}`;
  } else if (pattern === "form") {
    title = t.match(/заявк|отпуск|создан/i) ? "Создание заявки" : "Новая форма";
  } else if (pattern === "dashboard") {
    title = "Дашборд";
  } else {
    title = `Список ${entityMatch.entity}`;
  }

  const fields = [];
  if (pattern === "form" || /отпуск/i.test(t)) {
    if (/отпуск/i.test(t)) {
      fields.push(
        { id: "type", label: "Тип отпуска", type: "select", options: ["Ежегодный", "Без сохранения ЗП", "Учебный"] },
        { id: "dates", label: "Период", type: "text", placeholder: "дд.мм.гггг — дд.мм.гггг" },
        { id: "comment", label: "Комментарий", type: "textarea", optional: true }
      );
    } else {
      fields.push(
        { id: "name", label: "Название", type: "text", placeholder: "Введите название" },
        { id: "desc", label: "Описание", type: "textarea", optional: true }
      );
    }
  }

  const columns = ["Название", "Статус", "Дата"];
  if (/отдел|department/i.test(t)) columns.splice(2, 0, "Отдел");

  const actions = [];
  if (/добав|созда|нов/i.test(t) || pattern === "list") {
    actions.push({ id: "create", label: pattern === "form" ? "Отправить" : `Добавить`, variant: "default" });
  }
  if (pattern === "form") actions.push({ id: "cancel", label: "Отмена", variant: "secondary" });
  if (pattern === "list" && !actions.some((a) => a.id === "create")) {
    actions.push({ id: "create", label: "Добавить", variant: "default" });
  }

  const filters = [];
  if (/фильтр|filter|поиск|search/i.test(t)) {
    filters.push("status");
  }

  const stats = pattern === "dashboard"
    ? [
        { label: "Всего", value: "1 248", delta: "+12%" },
        { label: "В работе", value: "86", delta: "+3%" },
        { label: "Закрыто", value: "342", delta: "+8%" },
        { label: "Среднее время", value: "2.4 дн", delta: "-6%" },
      ]
    : [];

  const rows = entityMatch.sample.map((name, i) => ({
    id: String(i + 1),
    cells: buildRowCells(name, columns, i),
  }));

  return {
    pattern,
    view: pattern === "form" ? "form" : pattern === "dashboard" ? "dashboard" : "list",
    title,
    subtitle: pattern === "list" ? `Обзор ${entityMatch.entity} с фильтрами и действиями` : "",
    entity: entityMatch,
    columns,
    rows,
    fields,
    actions,
    filters,
    stats,
    searchEnabled: /поиск|search|фильтр|filter/i.test(t),
    breadcrumbs: [{ label: "Главная", view: "list" }, { label: title, view: null }],
    activeTab: 0,
    detailItem: null,
  };
}

function buildRowCells(name, columns, index) {
  const statuses = [
    { label: "Активен", tone: "success" },
    { label: "На согласовании", tone: "warning" },
    { label: "Черновик", tone: "default" },
    { label: "Архив", tone: "destructive" },
  ];
  const status = statuses[index % statuses.length];
  const date = `0${(index % 9) + 1}.07.2026`;

  const cells = {};
  columns.forEach((col) => {
    if (col === "Название") cells[col] = name;
    else if (col === "Статус") cells[col] = status;
    else if (col === "Отдел") cells[col] = ["HR", "IT", "Финансы", "Маркетинг"][index % 4];
    else if (col === "Дата") cells[col] = date;
    else cells[col] = "—";
  });
  return cells;
}

export function applyRefinement(state, text) {
  const next = { ...state, version: state.version + 1 };
  const t = text.trim();
  const lower = t.toLowerCase();

  if (/заголовок|title|название экрана/i.test(t)) {
    const m = t.match(/[«"]([^»"]+)[»"]|на\s+(.+?)(?:\.|$)/i);
    if (m) next.title = (m[1] || m[2] || "").trim();
    return { state: next, note: `Заголовок → «${next.title}»` };
  }

  if (/добав(ь|ить)\s+(кнопк|action)|кнопк.*добав/i.test(t)) {
    const labelMatch = t.match(/[«"]([^»"]+)[»"]/);
    const label = labelMatch ? labelMatch[1] : "Экспорт";
    if (!next.actions.find((a) => a.label === label)) {
      next.actions = [...next.actions, { id: `action-${next.actions.length}`, label, variant: "outline" }];
    }
    return { state: next, note: `Добавлена кнопка «${label}»` };
  }

  if (/поиск|search|фильтр/i.test(t)) {
    next.searchEnabled = true;
    if (!next.filters.includes("status")) next.filters = [...next.filters, "status"];
    return { state: next, note: "Добавлены поиск и фильтр по статусу" };
  }

  if (/колонк|column|отдел|department/i.test(t)) {
    if (!next.columns.includes("Отдел")) {
      next.columns = [...next.columns.slice(0, 2), "Отдел", ...next.columns.slice(2)];
      next.rows = next.rows.map((row, i) => ({
        ...row,
        cells: { ...row.cells, Отдел: ["HR", "IT", "Финансы", "Маркетинг"][i % 4] },
      }));
    }
    return { state: next, note: "Добавлена колонка «Отдел»" };
  }

  if (/форм|form|создан/i.test(t) && next.view === "list") {
    next.view = "form";
    next.pattern = "form";
    if (!next.fields.length) {
      next.fields = [
        { id: "name", label: "Название", type: "text" },
        { id: "desc", label: "Описание", type: "textarea", optional: true },
      ];
    }
    next.actions = [
      { id: "submit", label: "Отправить", variant: "default" },
      { id: "cancel", label: "Отмена", variant: "secondary" },
    ];
    next.breadcrumbs = [
      { label: "Главная", view: "list" },
      { label: next.title, view: "list" },
      { label: "Создание", view: null },
    ];
    return { state: next, note: "Переключено на форму создания" };
  }

  if (/список|list|таблиц|table/i.test(t)) {
    next.view = "list";
    next.pattern = "list";
    return { state: next, note: "Вернул список" };
  }

  if (/дашборд|dashboard/i.test(t)) {
    next.view = "dashboard";
    next.pattern = "dashboard";
    next.stats = [
      { label: "Всего", value: "1 248", delta: "+12%" },
      { label: "В работе", value: "86", delta: "+3%" },
      { label: "Закрыто", value: "342", delta: "+8%" },
      { label: "Среднее время", value: "2.4 дн", delta: "-6%" },
    ];
    return { state: next, note: "Собран дашборд с метриками" };
  }

  if (/пуст|empty state/i.test(t)) {
    next.rows = [];
    return { state: next, note: "Показан empty state" };
  }

  if (/заполн|demo|пример|данн/i.test(t) && !next.rows.length) {
    next.rows = state.entity.sample.map((name, i) => ({
      id: String(i + 1),
      cells: buildRowCells(name, next.columns, i),
    }));
    return { state: next, note: "Заполнил демо-данными" };
  }

  return {
    state: { ...next, subtitle: next.subtitle || "Обновлено по вашим правкам" },
    note: "Применил правки к текущему прототипу",
  };
}

export function buildAssistantReply(state, userText, isRefinement) {
  const lines = [];

  if (!isRefinement) {
    lines.push(`Понял задачу. Собрал прототип на shadcn-компонентах (тестовый режим).`);
    lines.push("");
    lines.push(`Паттерн: ${patternLabel(state.pattern)}`);
    lines.push(`Экран: ${state.title}`);
    if (state.searchEnabled) lines.push("• Поиск и фильтры");
    if (state.fields.length) lines.push(`• Поля формы: ${state.fields.map((f) => f.label).join(", ")}`);
    if (state.actions.length) lines.push(`• Действия: ${state.actions.map((a) => a.label).join(", ")}`);
    lines.push("");
    lines.push("Справа — кликабельный preview. Можно кликать по строкам, кнопкам и вкладкам.");
    lines.push("Дальше пишите доработки: «добавь кнопку Экспорт», «добавь колонку Отдел».");
  } else {
    lines.push("Обновил прототип.");
    lines.push("Проверьте preview справа — изменения уже применены.");
  }

  return lines.join("\n");
}

function patternLabel(pattern) {
  const map = { list: "List / Data Table", form: "Form Flow", dashboard: "Dashboard", detail: "Detail" };
  return map[pattern] || pattern;
}

export function renderPrototypeDocument(state) {
  const body = renderBody(state);
  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>${PROTOTYPE_INLINE_CSS}</style>
</head>
<body>
  <div class="proto-app" data-version="${state.version}">
    ${body}
  </div>
  <script>${getPrototypeScript()}</script>
</body>
</html>`;
}

function renderBody(state) {
  if (state.view === "success") return renderSuccess(state);
  if (state.view === "detail" && state.detailItem) return renderDetail(state);
  if (state.view === "form") return renderForm(state);
  if (state.view === "dashboard") return renderDashboard(state);
  return renderList(state);
}

function renderList(state) {
  const breadcrumbs = renderBreadcrumbs(state);
  const actions = state.actions
    .map(
      (a) =>
        `<button type="button" class="sh-btn sh-btn--${a.variant || "default"}" data-action="${a.id}">${escapeHtml(a.label)}</button>`
    )
    .join("");

  const toolbar = state.searchEnabled
    ? `<div class="proto-toolbar">
        <div class="proto-search">
          <span class="proto-search-icon" aria-hidden="true">⌕</span>
          <input type="search" placeholder="Поиск…" data-search />
        </div>
        ${state.filters.length ? `<button type="button" class="sh-btn sh-btn--outline sh-btn--sm" data-action="filter">Фильтр</button>` : ""}
      </div>`
    : "";

  const tableBody =
    state.rows.length === 0
      ? `<div class="proto-empty"><h3>Нет данных</h3><p>Добавьте первую запись или измените фильтры.</p></div>`
      : `<div class="proto-table-wrap"><table class="proto-table"><thead><tr>${state.columns
          .map((c) => `<th>${escapeHtml(c)}</th>`)
          .join("")}</tr></thead><tbody>${state.rows
          .map(
            (row) =>
              `<tr data-row="${row.id}">${state.columns
                .map((col) => {
                  const val = row.cells[col];
                  if (col === "Статус" && val && typeof val === "object") {
                    return `<td><span class="proto-badge proto-badge--${val.tone}">${escapeHtml(val.label)}</span></td>`;
                  }
                  return `<td>${escapeHtml(String(val ?? ""))}</td>`;
                })
                .join("")}</tr>`
          )
          .join("")}</tbody></table></div>`;

  return `<div class="proto-shell">
    <header class="proto-header">
      <div class="proto-header-main">
        ${breadcrumbs}
        <h1 class="proto-title">${escapeHtml(state.title)}</h1>
        ${state.subtitle ? `<p class="proto-subtitle">${escapeHtml(state.subtitle)}</p>` : ""}
      </div>
      <div class="proto-header-actions">${actions}</div>
    </header>
    <main class="proto-content">
      ${toolbar}
      <div class="proto-card">${tableBody}</div>
    </main>
  </div>`;
}

function renderForm(state) {
  const fields = state.fields
    .map((f) => {
      const optional = f.optional ? ` <span class="proto-label-hint">(необязательно)</span>` : "";
      let control = "";
      if (f.type === "select") {
        control = `<select class="proto-select" id="${f.id}">${(f.options || [])
          .map((o) => `<option>${escapeHtml(o)}</option>`)
          .join("")}</select>`;
      } else if (f.type === "textarea") {
        control = `<textarea class="proto-textarea" id="${f.id}" placeholder="${escapeHtml(f.placeholder || "")}"></textarea>`;
      } else {
        control = `<input class="proto-input" id="${f.id}" type="text" placeholder="${escapeHtml(f.placeholder || "")}" />`;
      }
      return `<div class="proto-field"><label class="proto-label" for="${f.id}">${escapeHtml(f.label)}${optional}</label>${control}</div>`;
    })
    .join("");

  const actions = state.actions
    .map(
      (a) =>
        `<button type="button" class="sh-btn sh-btn--${a.variant || "default"}" data-action="${a.id}">${escapeHtml(a.label)}</button>`
    )
    .join("");

  return `<div class="proto-shell">
    <header class="proto-header">
      <div class="proto-header-main">
        ${renderBreadcrumbs(state)}
        <h1 class="proto-title">${escapeHtml(state.title)}</h1>
      </div>
    </header>
    <main class="proto-content">
      <form class="proto-form" data-proto-form onsubmit="return false">
        ${fields}
        <div class="proto-form-actions">${actions}</div>
      </form>
    </main>
  </div>`;
}

function renderDashboard(state) {
  const stats = state.stats
    .map(
      (s) =>
        `<div class="proto-stat"><div class="proto-stat-label">${escapeHtml(s.label)}</div><div class="proto-stat-value">${escapeHtml(s.value)}</div><div class="proto-stat-delta">${escapeHtml(s.delta)}</div></div>`
    )
    .join("");

  return `<div class="proto-shell">
    <header class="proto-header">
      <div class="proto-header-main">
        ${renderBreadcrumbs(state)}
        <h1 class="proto-title">${escapeHtml(state.title)}</h1>
        <p class="proto-subtitle">Ключевые метрики и последние ${escapeHtml(state.entity.entity)}</p>
      </div>
      <div class="proto-header-actions">
        <button type="button" class="sh-btn sh-btn--outline" data-action="export">Экспорт</button>
        <button type="button" class="sh-btn sh-btn--default" data-action="create">Добавить</button>
      </div>
    </header>
    <main class="proto-content">
      <div class="proto-stats">${stats}</div>
      <div class="proto-tabs">
        <button type="button" class="proto-tab is-active" data-tab="0">Обзор</button>
        <button type="button" class="proto-tab" data-tab="1">Динамика</button>
        <button type="button" class="proto-tab" data-tab="2">Отчёты</button>
      </div>
      <div class="proto-card">
        <div class="proto-table-wrap">
          <table class="proto-table">
            <thead><tr><th>Название</th><th>Статус</th><th>Дата</th></tr></thead>
            <tbody>
              ${state.rows
                .slice(0, 4)
                .map((row, i) => {
                  const name = row.cells["Название"] || row.cells[state.columns[0]];
                  const st = row.cells["Статус"];
                  const date = row.cells["Дата"] || "01.07.2026";
                  return `<tr data-row="${row.id}"><td>${escapeHtml(String(name))}</td><td><span class="proto-badge proto-badge--${st?.tone || "default"}">${escapeHtml(st?.label || "—")}</span></td><td>${escapeHtml(String(date))}</td></tr>`;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>`;
}

function renderDetail(state) {
  const item = state.detailItem;
  const cells = item?.cells || {};
  const name = cells["Название"] || cells[state.columns[0]] || "Запись";

  return `<div class="proto-shell">
    <header class="proto-header">
      <div class="proto-header-main">
        ${renderBreadcrumbs(state)}
        <h1 class="proto-title">${escapeHtml(String(name))}</h1>
        <p class="proto-subtitle">Карточка ${escapeHtml(state.entity.singular)}</p>
      </div>
      <div class="proto-header-actions">
        <button type="button" class="sh-btn sh-btn--outline" data-action="back">Назад</button>
        <button type="button" class="sh-btn sh-btn--default" data-action="edit">Редактировать</button>
      </div>
    </header>
    <main class="proto-content">
      <div class="proto-detail-grid">
        ${state.columns
          .map((col) => {
            let val = cells[col];
            if (col === "Статус" && val && typeof val === "object") val = val.label;
            return `<div class="proto-detail-item"><div class="proto-detail-label">${escapeHtml(col)}</div><div class="proto-detail-value">${escapeHtml(String(val ?? "—"))}</div></div>`;
          })
          .join("")}
      </div>
    </main>
  </div>`;
}

function renderSuccess(state) {
  return `<div class="proto-shell">
    <main class="proto-content">
      <div class="proto-success">
        <div class="proto-success-icon" aria-hidden="true">✓</div>
        <h1 class="proto-title">Заявка отправлена</h1>
        <p class="proto-subtitle">Прототип: success state после submit. В проде здесь будет redirect или toast.</p>
        <div style="margin-top:1.5rem;display:flex;gap:0.5rem;justify-content:center">
          <button type="button" class="sh-btn sh-btn--default" data-action="back">К списку</button>
          <button type="button" class="sh-btn sh-btn--outline" data-action="create">Создать ещё</button>
        </div>
      </div>
    </main>
  </div>`;
}

function renderBreadcrumbs(state) {
  if (!state.breadcrumbs?.length) return "";
  const items = state.breadcrumbs
    .map((crumb, i) => {
      const isLast = i === state.breadcrumbs.length - 1;
      if (isLast || !crumb.view) return `<li>${escapeHtml(crumb.label)}</li>`;
      return `<li><a data-nav="${crumb.view}">${escapeHtml(crumb.label)}</a></li>`;
    })
    .join('<li aria-hidden="true">/</li>');
  return `<ul class="proto-breadcrumbs">${items}</ul>`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const PROTOTYPE_INLINE_CSS = `
:root{--background:hsl(0 0% 100%);--foreground:hsl(240 10% 3.9%);--card:hsl(0 0% 100%);--primary:hsl(240 5.9% 10%);--primary-foreground:hsl(0 0% 98%);--secondary:hsl(240 4.8% 95.9%);--secondary-foreground:hsl(240 5.9% 10%);--muted:hsl(240 4.8% 95.9%);--muted-foreground:hsl(240 3.8% 46.1%);--border:hsl(240 5.9% 90%);--input:hsl(240 5.9% 90%);--radius:0.5rem;--font-sans:Inter,ui-sans-serif,system-ui,sans-serif}
*{box-sizing:border-box}body{margin:0;font-family:var(--font-sans);background:var(--background);color:var(--foreground);font-size:14px;line-height:1.5}
.sh-btn{display:inline-flex;align-items:center;justify-content:center;height:2.25rem;padding:0 .875rem;border-radius:calc(var(--radius) - 2px);font-size:.875rem;font-weight:500;border:1px solid transparent;cursor:pointer}
.sh-btn--default{background:var(--primary);color:var(--primary-foreground)}.sh-btn--secondary{background:var(--secondary);color:var(--secondary-foreground);border-color:var(--border)}.sh-btn--outline{background:var(--background);border-color:var(--border)}
.proto-shell{min-height:100vh;display:flex;flex-direction:column}.proto-header{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;padding:1.5rem;border-bottom:1px solid var(--border)}.proto-title{margin:0;font-size:1.5rem;font-weight:600}.proto-subtitle{margin:.25rem 0 0;color:var(--muted-foreground);font-size:.875rem}
.proto-breadcrumbs{display:flex;flex-wrap:wrap;gap:.375rem;margin:0 0 .5rem;padding:0;list-style:none;font-size:.75rem;color:var(--muted-foreground)}.proto-breadcrumbs a{color:inherit;cursor:pointer;text-decoration:none}
.proto-content{flex:1;padding:1.5rem}.proto-header-actions,.proto-form-actions{display:flex;gap:.5rem;flex-wrap:wrap}.proto-card{border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.proto-table{width:100%;border-collapse:collapse}.proto-table th,.proto-table td{padding:.75rem 1rem;text-align:left;border-bottom:1px solid var(--border)}.proto-table th{font-size:.75rem;color:var(--muted-foreground);background:hsl(240 4.8% 97.5%)}.proto-table tbody tr{cursor:pointer}.proto-table tbody tr:hover{background:var(--muted)}
.proto-badge{display:inline-flex;border-radius:999px;padding:.125rem .5rem;font-size:.75rem;font-weight:500}.proto-badge--success{background:hsl(142 76% 36% / .12);color:hsl(142 72% 29%)}.proto-badge--warning{background:hsl(38 92% 50% / .12);color:hsl(32 95% 35%)}.proto-badge--default{background:var(--secondary)}.proto-badge--destructive{background:hsl(0 84% 60% / .12);color:hsl(0 72% 40%)}
.proto-toolbar{display:flex;gap:.75rem;margin-bottom:1rem;flex-wrap:wrap}.proto-search{position:relative;flex:1;min-width:200px;max-width:320px}.proto-search input{width:100%;height:2.25rem;padding:0 .75rem 0 2.25rem;border:1px solid var(--input);border-radius:calc(var(--radius)-2px)}.proto-search-icon{position:absolute;left:.75rem;top:50%;transform:translateY(-50%);color:var(--muted-foreground)}
.proto-form{max-width:560px;display:flex;flex-direction:column;gap:1.25rem}.proto-field{display:flex;flex-direction:column;gap:.375rem}.proto-label{font-size:.875rem;font-weight:500}.proto-label-hint{font-weight:400;color:var(--muted-foreground)}.proto-input,.proto-select,.proto-textarea{width:100%;border:1px solid var(--input);border-radius:calc(var(--radius)-2px);padding:.5rem .75rem;font:inherit}.proto-textarea{min-height:96px}
.proto-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1.5rem}.proto-stat{padding:1rem;border:1px solid var(--border);border-radius:var(--radius)}.proto-stat-label{font-size:.75rem;color:var(--muted-foreground)}.proto-stat-value{font-size:1.5rem;font-weight:600}.proto-stat-delta{font-size:.75rem;color:hsl(142 72% 29%)}
.proto-tabs{display:flex;gap:.25rem;margin-bottom:1rem;border-bottom:1px solid var(--border)}.proto-tab{padding:.5rem .875rem;background:none;border:none;border-bottom:2px solid transparent;margin-bottom:-1px;cursor:pointer;color:var(--muted-foreground);font-weight:500}.proto-tab.is-active{color:var(--foreground);border-bottom-color:var(--primary)}
.proto-empty{padding:3rem;text-align:center;color:var(--muted-foreground)}.proto-success{max-width:420px;margin:2rem auto;text-align:center;padding:2rem}.proto-success-icon{width:48px;height:48px;margin:0 auto 1rem;border-radius:50%;background:hsl(142 76% 36% / .12);color:hsl(142 72% 29%);display:grid;place-items:center;font-size:1.25rem}
.proto-detail-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem}.proto-detail-item{padding:.75rem 0;border-bottom:1px solid var(--border)}.proto-detail-label{font-size:.75rem;color:var(--muted-foreground)}.proto-detail-value{font-weight:500}
.proto-toast{position:fixed;bottom:1rem;right:1rem;padding:.75rem 1rem;background:var(--primary);color:var(--primary-foreground);border-radius:var(--radius);font-size:.8125rem;z-index:50}
`;

function getPrototypeScript() {
  return `
(function(){
  function toast(msg){
    var el=document.createElement('div');
    el.className='proto-toast';
    el.textContent=msg;
    document.body.appendChild(el);
    setTimeout(function(){el.remove();},2200);
  }
  document.addEventListener('click',function(e){
    var row=e.target.closest('[data-row]');
    if(row){ parent.postMessage({type:'proto-nav',action:'detail',rowId:row.dataset.row},'*'); return; }
    var btn=e.target.closest('[data-action]');
    if(!btn) return;
    var action=btn.dataset.action;
    if(action==='create'||action==='edit') parent.postMessage({type:'proto-nav',action:'form'},'*');
    else if(action==='submit'||action==='cancel'&&document.querySelector('[data-proto-form]')) parent.postMessage({type:'proto-nav',action:action==='submit'?'success':'list'},'*');
    else if(action==='cancel'||action==='back') parent.postMessage({type:'proto-nav',action:'list'},'*');
    else if(action==='filter'||action==='export') toast(action==='filter'?'Фильтр (demo)':'Экспорт (demo)');
    else parent.postMessage({type:'proto-nav',action:action},'*');
    var nav=e.target.closest('[data-nav]');
    if(nav) parent.postMessage({type:'proto-nav',action:nav.dataset.nav},'*');
  });
  document.querySelectorAll('.proto-tab').forEach(function(tab){
    tab.addEventListener('click',function(){
      document.querySelectorAll('.proto-tab').forEach(function(t){t.classList.remove('is-active');});
      tab.classList.add('is-active');
      toast('Вкладка: '+tab.textContent);
    });
  });
  var search=document.querySelector('[data-search]');
  if(search){
    search.addEventListener('input',function(){
      var q=search.value.toLowerCase();
      document.querySelectorAll('[data-row]').forEach(function(row){
        row.style.display=row.textContent.toLowerCase().includes(q)?'':'none';
      });
    });
  }
})();
`;
}
